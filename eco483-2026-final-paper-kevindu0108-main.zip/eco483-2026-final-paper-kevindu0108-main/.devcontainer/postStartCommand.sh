#!/bin/bash
set +e

# Install Stata and packages
if [ -f stata.lic.encrypted ]; then
    ./automation/stata_install.py --no-upgrade --install-source=decrypt --license-source=decrypt --version="$(yq eval '.stata_version' automation/config.yaml)" --edition="be" --add requirements
    echo "✅ Stata license and package installation complete"
else
    ./automation/stata_install.py --no-upgrade --install-source=decrypt --license-source=cache --version="$(yq eval '.stata_version' automation/config.yaml)" --edition="be"
    echo "✅ Stata installed; license missing."
fi

# Re-install Stata license and packages whenever stata.lic.encrypted or packages-stata.txt is modified in a merge or a commit

# Update Stata packages whenever packages-stata.txt is modified in a merge or a commit
# Update Python packages whenever packages-python.txt is modified in a merge or a commit
# Update R packages whenever packages-r.txt is modified in a merge or a commit

### Update the post-merge hook
cat << 'EOF' >> .git/hooks/post-merge
if git diff --name-only HEAD@{1} HEAD | grep -Eq 'stata.lic.encrypted|packages-stata.txt'; then
    ./automation/stata_install.py --no-upgrade --install-source=cache --license-source=decrypt --version="$(yq eval '.stata_version' automation/config.yaml)" --edition="be" --add requirements
fi
if git diff --name-only HEAD@{1} HEAD | grep -q 'packages-python.txt'; then
    uv pip install --cache-dir "/workspaces/.uv_cache" -r packages-python.txt
fi
if git diff --name-only HEAD@{1} HEAD | grep -q 'packages-r.txt'; then
    ./automation/r_install_dependencies.sh -r packages-r.txt
fi
EOF

### Create the post-commit hook
cat << 'EOF' > .git/hooks/post-commit
#!/bin/sh
if git diff-tree --no-commit-id --name-only -r HEAD | grep -Eq 'stata.lic.encrypted|packages-stata.txt'; then
    ./automation/stata_install.py --install-source=cache --license-source=decrypt --version="$(yq eval '.stata_version' automation/config.yaml)" --edition="be" --add requirements
fi
if git diff-tree --no-commit-id --name-only -r HEAD | grep -q 'packages-python.txt'; then
    uv pip install --cache-dir "/workspaces/.uv_cache" -r packages-python.txt
fi
if git diff-tree --no-commit-id --name-only -r HEAD | grep -q 'packages-r.txt'; then
    ./automation/r_install_dependencies.sh -r packages-r.txt
fi
EOF
chmod +x .git/hooks/post-commit

echo "✅ Git post-merge and post-commit hook configuration complete"

# Pull raw data using DVC
if [ -f .dvc/config ]; then
    dvc pull
    echo "✅ DVC pull complete"
fi

exit 0
