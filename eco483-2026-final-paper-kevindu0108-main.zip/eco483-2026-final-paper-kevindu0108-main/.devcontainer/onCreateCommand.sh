#!/bin/bash
set +e

# Create default folder structure
mkdir -p results data/derived

# Configure git
if [ -f "automation/default_commit_message.txt" ]; then
    git config --local commit.template automation/default_commit_message.txt
fi
git config --global pull.rebase true
echo "✅ Git configuration complete"

# Custom welcome message
cat <<'EOF' >> /home/vscode/.bashrc

# Custom welcome message
echo -e "$(cat /home/vscode/.welcome_message)"
echo ""
status-python
status-r
status-stata
EOF
echo "✅ Custom welcome message configuration complete"

# Configure DVC
if [ -f .dvc/config ]; then
    if [ -n "$GDRIVE_CREDENTIALS_DATA" ]; then
        dvc remote modify myremote --local gdrive_use_service_account true
    fi
    dvc install
    printf '#!/bin/sh\ndvc pull' > .git/hooks/post-merge && chmod +x .git/hooks/post-merge
    echo "✅ DVC configuration complete"
else
    echo '#!/bin/sh' > .git/hooks/post-merge && chmod +x .git/hooks/post-merge
    echo "⏩ .dvc/config does not exist, skipping DVC configuration"
fi

# Configure cache directory for uv
#    This keeps the cache on the same filesystem as the virtual environment,
#    which allows uv to use hardlinks, improving performance and reducing disk usage.
mkdir -p /workspaces/.uv_cache
export UV_CACHE_DIR=/workspaces/.uv_cache
echo '' >> /home/vscode/.bashrc
echo 'export UV_CACHE_DIR=/workspaces/.uv_cache' >> /home/vscode/.bashrc

# Install Python using uv (https://docs.astral.sh/uv)
python_version="$(yq eval '.python_version' automation/config.yaml)"
uv venv --python "$python_version"
echo "✅ Python version $python_version installed"

# Install Jupyter kernel for Stata using uv (https://hugetim.github.io/nbstata/user_guide.html#install)
uv pip install nbstata setuptools
uv run python -m nbstata.install --sys-prefix
sed -i 's/^stata_dir = $/stata_dir = \/usr\/local\/stata/' .venv/etc/nbstata.conf
sed -i 's/^edition = $/edition = be/' .venv/etc/nbstata.conf
echo "✅ Jupyter kernel for Stata installed, Stata path specified"

# Install packages for Python, R and Stata
if [ -f packages-python.txt ]; then
    uv pip install -r packages-python.txt
    echo "✅ Python package installation complete"
else
    echo "⏩ packages-python.txt does not exist, skipping Python package installation"
fi

if [ -f packages-r.txt ]; then
    ./automation/r_install_dependencies.sh -r packages-r.txt
    echo "✅ R package installation complete"
else
    echo "⏩ packages-r.txt does not exist, skipping R package installation"
fi

echo "⏩ Skipping Stata package installation, Stata will be installed in the next startup step"
# if [ -f packages-stata.txt ]; then
#     /opt/stata_install.py --no-upgrade --install-source=cache --license-source=cache --version="$(yq eval '.stata_version' automation/config.yaml)" --edition="mp" --add requirements
#     echo "✅ Stata package installation complete"
# else
#     echo "⏩ packages-stata.txt does not exist, skipping Stata package installation"
# fi

# Configure the Spyder IDE
mkdir -p /home/vscode/.config/spyder-py3/config
cat <<'EOF' > "/home/vscode/.config/spyder-py3/config/spyder.ini"
[main]
show_internal_errors = False
check_updates_on_startup = False

[main_interpreter]
default = False
custom = True

[workingdir]
console/use_cwd = False
console/use_fixed_directory = True
startup/use_project_or_home_directory = False
startup/use_fixed_directory = True
EOF
cat << EOF > "/home/vscode/.config/spyder-py3/config/transient.ini"
[main_interpreter]
custom_interpreters_list = ['$(pwd)/.venv/bin/python']
custom_interpreter = $(pwd)/.venv/bin/python
executable = $(pwd)/.venv/bin/python

[workingdir]
startup/fixed_directory = $(pwd)
console/fixed_directory = $(pwd)
EOF

# Set RStudio's default working directory to the root of the git repository
mkdir -p /home/vscode/.config/rstudio
echo "{\"initial_working_directory\":\"$(pwd)\"}" > /home/vscode/.config/rstudio/rstudio-prefs.json

# Add a bookmark to the root of the git repository in the file explorer
mkdir -p /home/vscode/.config/gtk-3.0
echo "file://$(pwd)" >> /home/vscode/.config/gtk-3.0/bookmarks
cat <<EOF > "/home/vscode/.config/QtProject.conf"
[FileDialog]
shortcuts=file:, file://$(pwd)
sidebarWidth=175
EOF

exit 0
